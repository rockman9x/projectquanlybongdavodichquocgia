using System;
using System.Collections.Generic;
using System.Text;

namespace V_League
{
    public static class GlobalVariables
    {
        public static String g_strPath;
        public static String g_strRole;
        public static int g_strUserID;
        public static String g_strUserName;
        public static String g_strPassword;
    }
}
