using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class DoiBongDTO
    {
#region "Attributes"
        private int _MaDoiBong;
        private String _TenDoiBong;
        private String _DiaChi;
        private String _SanNha;
        private String _HLV;
#endregion
#region "Properties"
        public int maDoiBong
        {
          get { return _MaDoiBong; }
          set { _MaDoiBong = value; }
        }
       
        public String tenDoiBong
        {
          get { return _TenDoiBong; }
          set { _TenDoiBong = value; }
        }
        
        public String diaChi
        {
          get { return _DiaChi; }
          set { _DiaChi = value; }
        }
                
        public String sanNha
        {
          get { return _SanNha; }
          set { _SanNha = value; }
        }
               

        public String hlv
        {
          get { return _HLV; }
          set { _HLV = value; }
        }
#endregion
#region "Constructors"
        public DoiBongDTO()
        {
        }
#endregion
    }
}
