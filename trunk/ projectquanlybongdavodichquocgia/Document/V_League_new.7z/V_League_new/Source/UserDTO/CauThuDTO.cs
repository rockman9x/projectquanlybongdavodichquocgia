using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class CauThuDTO
    {
#region "Attributes"
        private int _MaCauThu;
        private String _TenCauThu;
        private int _NgaySinh;
        private int _ThangSinh;
        private int _NamSinh;
        private int _SoAo;
        private String _ViTri;
        private String _QuocTich;
        private int _MaDoiBong;
#endregion
#region "Properties"

        public int maDoiBong
        {
            get { return _MaDoiBong; }
            set { _MaDoiBong = value; }
        }

        public int maCauThu
        {
            get { return _MaCauThu; }
            set { _MaCauThu = value; }
        }

        public String tenCauThu
        {
            get { return _TenCauThu; }
            set { _TenCauThu = value; }
        }

        public int ngaySinh
        {
            get { return _NgaySinh; }
            set { _NgaySinh = value; }
        }

        public int thangSinh
        {
            get { return _ThangSinh; }
            set { _ThangSinh = value; }
        }

        public int namSinh
        {
            get { return _NamSinh; }
            set { _NamSinh = value; }
        }

        public int soAo
        {
            get { return _SoAo; }
            set { _SoAo = value; }
        }

        public String viTri
        {
            get { return _ViTri; }
            set { _ViTri = value; }
        }


        public String quocTich
        {
            get { return _QuocTich; }
            set { _QuocTich = value; }
        }
#endregion
#region "Constructors"
        public CauThuDTO()
        {
        }
#endregion
    }
}
