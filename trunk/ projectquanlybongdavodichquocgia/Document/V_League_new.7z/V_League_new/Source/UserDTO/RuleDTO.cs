using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class RuleDTO
    {
#region "Attributes"
        private int _RuleID;
        private String _RuleName;
        private int _RuleValue;
#endregion
#region "Properties"
        public int ruleID
        {
            get
            {
                return _RuleID;
            }
            set
            {
                _RuleID = value;
            }
        }
        public String ruleName
        {
            get
            {
                return _RuleName;
            }
            set
            {
                _RuleName = value;
            }
        }
        public int ruleValue
        {
            get
            {
                return _RuleValue;
            }
            set
            {
                _RuleValue= value;
            }
        }
#endregion
#region "Constructors"
        public RuleDTO()
        {
        }
#endregion
    }
}
