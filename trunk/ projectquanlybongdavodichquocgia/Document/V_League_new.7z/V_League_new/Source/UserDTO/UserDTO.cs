using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class UserDTO
    {
#region "Attributes"
        private int _userID;
        private String _Username;
        private String _Password;
        private String _Role;
#endregion
#region "Properties"
        public int userID
        {
            get
            {
                return _userID;
            }
            set
            {
                _userID = value;
            }
        }
        public String userName
        {
            get
            {
                return _Username;
            }
            set
            {
                _Username = value;
            }
        }
        public String passWord
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password= value;
            }
        }
        public String role
        {
            get
            {
                return _Role;
            }
            set
            {
                _Role = value;
            }
        }
#endregion
#region "Constructors"
        public UserDTO()
        {
        }
#endregion
    }
}
