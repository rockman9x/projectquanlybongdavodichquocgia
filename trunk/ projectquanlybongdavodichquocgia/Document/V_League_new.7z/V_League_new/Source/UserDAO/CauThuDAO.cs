using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using DTO;
namespace DAO
{
    public class CauThuDAO : AbstractDAO
    {
        public CauThuDAO(String strPath):base(strPath)
        {

        }
        ~CauThuDAO()
        {
            base.Dispose();
        }
        public DataSet SelectCauThu(int maDoiBong)
        {
            DataSet ds;
            try
            {
                ds = new DataSet();
                base.Access = "usp_SelectCauThuByDoiBong";

                base.InitializeCommand();

                base.AddParameter("@MaDoiBong",
                OleDbType.Integer, 10, maDoiBong);

                base.FillDataSet(ref ds, "CauThu");
                return ds;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
        public DataSet SelectCauThuID(int maCauThu)
        {
            DataSet dsID;
            try
            {
                dsID = new DataSet();
                base.Access = "usp_SelectCauThuID";
                base.InitializeCommand();

                base.AddParameter("@MaCauThu",
                OleDbType.Integer, 10, maCauThu);

                base.FillDataSet(ref dsID, "CauThuID");
                return dsID;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
        public Boolean InsertCauThu(CauThuDTO cauthu)
        {
            try
            {
                base.Access = "usp_InsertCauThu";
                base.InitializeCommand();

                base.AddParameter("@TenCauThu",
                OleDbType.VarChar, 100, cauthu.tenCauThu);

                base.AddParameter("@NgaySinh",
                OleDbType.Integer, 10, cauthu.ngaySinh);

                base.AddParameter("@ThangSinh",
                OleDbType.Integer, 10, cauthu.thangSinh);

                base.AddParameter("@NamSinh",
                OleDbType.Integer, 10, cauthu.namSinh);

                base.AddParameter("@SoAo",
                OleDbType.Integer, 10, cauthu.soAo);

                base.AddParameter("@ViTri",
                OleDbType.VarChar, 100, cauthu.viTri);

                base.AddParameter("@QuocTich",
                OleDbType.VarChar, 100, cauthu.quocTich);

                base.AddParameter("@MaDoiBong",
                OleDbType.Integer, 100, cauthu.maDoiBong);

                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
            	throw new System.Exception(ExceptionErr.Message, 
                ExceptionErr.InnerException);
            }
        }
        public Boolean DeleteCauThu(int maCauThu)
        {
            try
            {
                base.Access = "usp_DeleteCauThu";
                base.InitializeCommand();

                base.AddParameter("@MaCauThu",
                OleDbType.Integer, 10, maCauThu);
                
                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
                throw new System.Exception(ExceptionErr.Message,
                ExceptionErr.InnerException);
            }
        }
        public Boolean UpdateCauThu(CauThuDTO cauthu)
        {
            try
            {
                base.Access = "usp_UpdateCauThu";
                base.InitializeCommand();

                base.AddParameter("@TenCauThu",
                OleDbType.VarChar, 100, cauthu.tenCauThu);

                base.AddParameter("@NgaySinh",
                OleDbType.Integer, 10, cauthu.ngaySinh);

                base.AddParameter("@ThangSinh",
                OleDbType.Integer, 10, cauthu.thangSinh);

                base.AddParameter("@NamSinh",
                OleDbType.Integer, 10, cauthu.namSinh);

                base.AddParameter("@SoAo",
                OleDbType.Integer, 10, cauthu.soAo);

                base.AddParameter("@ViTri",
                OleDbType.VarChar, 100, cauthu.viTri);

                base.AddParameter("@QuocTich",
                OleDbType.VarChar, 100, cauthu.quocTich);

                base.AddParameter("@MaCauThu",
                OleDbType.Integer, 10, cauthu.maCauThu);

                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
                throw new System.Exception(ExceptionErr.Message,
                ExceptionErr.InnerException);
            }
        }
        
    }
}
