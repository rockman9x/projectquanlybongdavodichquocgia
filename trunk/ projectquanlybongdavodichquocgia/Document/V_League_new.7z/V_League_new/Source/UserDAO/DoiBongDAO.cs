using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using DTO;
namespace DAO
{
    public class DoiBongDAO : AbstractDAO
    {
        public DoiBongDAO(String strPath):base(strPath)
        {

        }
        ~DoiBongDAO()
        {
            base.Dispose();
        }
        public DataSet SelectDoiBong()
        {
            DataSet ds;
            try
            {
                ds = new DataSet();
                base.Access = "usp_SelectDoiBong";
                base.FillDataSet(ref ds, "DoiBong");
                return ds;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
        public DataSet SelectDoiBongID(int doiBongID)
        {
            DataSet dsID;
            try
            {
                dsID = new DataSet();
                base.Access = "usp_SelectDoiBongID";
                base.InitializeCommand();

                base.AddParameter("@MaDoiBong",
                OleDbType.Integer, 10, doiBongID);

                base.FillDataSet(ref dsID, "DoiBongID");
                return dsID;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
        public Boolean InsertDoiBong(DoiBongDTO doibong)
        {
            try
            {
                base.Access = "usp_InsertDoiBong";
                base.InitializeCommand();

                base.AddParameter("@TenDoiBong",
                OleDbType.VarChar, 100, doibong.tenDoiBong);

                base.AddParameter("@DiaChi",
                OleDbType.VarChar, 100, doibong.diaChi);

                base.AddParameter("@SanNha",
                OleDbType.VarChar, 100, doibong.sanNha);

                base.AddParameter("@HLV",
                OleDbType.VarChar, 100, doibong.hlv);

                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
            	throw new System.Exception(ExceptionErr.Message, 
                ExceptionErr.InnerException);
            }
        }
        public Boolean DeleteDoiBong(int doibongID)
        {
            try
            {
                base.Access = "usp_DeleteDoiBong";
                base.InitializeCommand();

                base.AddParameter("@MaDoiBong",
                OleDbType.Integer, 10, doibongID);
                
                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
                throw new System.Exception(ExceptionErr.Message,
                ExceptionErr.InnerException);
            }
        }
        public Boolean UpdateDoiBong(DoiBongDTO doibong)
        {
            try
            {
                base.Access = "usp_UpdateDoiBong";
                base.InitializeCommand();

                base.AddParameter("@TenDoiBong",
                OleDbType.VarChar, 100, doibong.tenDoiBong);

                base.AddParameter("@DiaChi",
                OleDbType.VarChar, 100, doibong.diaChi);

                base.AddParameter("@SanNha",
                OleDbType.VarChar, 100, doibong.sanNha);

                base.AddParameter("@HLV",
                OleDbType.VarChar, 100, doibong.hlv);

                base.AddParameter("@MaDoiBong",
                OleDbType.Integer, 10, doibong.maDoiBong);

                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
                throw new System.Exception(ExceptionErr.Message,
                ExceptionErr.InnerException);
            }
        }
        
    }
}
