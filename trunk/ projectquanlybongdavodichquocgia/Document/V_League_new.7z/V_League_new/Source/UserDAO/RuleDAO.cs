using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using DTO;
namespace DAO
{
    public class RuleDAO : AbstractDAO
    {
        public RuleDAO(String strPath):base(strPath)
        {

        }
        ~RuleDAO()
        {
            base.Dispose();
        }
        public DataSet SelectRules()
        {
            DataSet ds;
            try
            {
                ds = new DataSet();
                base.Access = "usp_SelectRules";
                base.FillDataSet(ref ds, "Rules");
                return ds;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
        public DataSet SelectRuleID(int ruleID)
        {
            DataSet dsID;
            try
            {
                dsID = new DataSet();
                base.Access = "usp_SelectRuleID";
                base.InitializeCommand();

                base.AddParameter("@RuleID",
                OleDbType.Integer, 10, ruleID);

                base.FillDataSet(ref dsID, "RuleID");
                return dsID;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
        public Boolean InsertRule(RuleDTO rule)
        {
            try
            {
                base.Access = "usp_InsertRule";
                base.InitializeCommand();

                base.AddParameter("@RuleName",
                OleDbType.VarChar, 100, rule.ruleName);

                base.AddParameter("@RuleValue",
                OleDbType.Integer, 10, rule.ruleValue);

                return ExecuteStoredProcedure();

            }
            catch (System.Exception ExceptionErr)
            {
            	throw new System.Exception(ExceptionErr.Message, 
                ExceptionErr.InnerException);
            }
        }
        public Boolean DeleteRule(int ruleID)
        {
            try
            {
                base.Access = "usp_DeleteRule";
                base.InitializeCommand();
                base.AddParameter("@RuleID",
                OleDbType.Integer, 10, ruleID);
                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
                throw new System.Exception(ExceptionErr.Message,
                ExceptionErr.InnerException);
            }
        }
        public Boolean UpdateRule(RuleDTO rule)
        {
            try
            {
                base.Access = "usp_UpdateRule";
                base.InitializeCommand();

                base.AddParameter("@RuleName",
                OleDbType.VarChar, 100, rule.ruleName);

                base.AddParameter("@RuleValue",
                OleDbType.Integer, 10, rule.ruleValue);

                base.AddParameter("@RuleID",
                OleDbType.Integer, 10, rule.ruleID);

                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
                throw new System.Exception(ExceptionErr.Message,
                ExceptionErr.InnerException);
            }
        }
        
    }
}
