using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using DTO;
namespace DAO
{
    public class UserDAO : AbstractDAO
    {
        public UserDAO(String strPath):base(strPath)
        {

        }
        ~UserDAO()
        {
            base.Dispose();
        }
        public DataSet SelectUsers()
        {
            DataSet ds;
            try
            {
                ds = new DataSet();
                base.Access = "usp_SelectUsers";
                base.FillDataSet(ref ds, "Users");
                return ds;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
        public DataSet SelectUserID(int usreID)
        {
            DataSet dsID;
            try
            {
                dsID = new DataSet();
                base.Access = "usp_SelectUserID";
                base.InitializeCommand();

                base.AddParameter("@UserID",
                OleDbType.Integer, 10, usreID);

                base.FillDataSet(ref dsID, "UserID");
                return dsID;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
        public Boolean InsertUser(UserDTO user)
        {
            try
            {
                base.Access = "usp_InsertUser";
                base.InitializeCommand();

                base.AddParameter("@UserName",
                OleDbType.VarChar, 20, user.userName);

                base.AddParameter("@PassWord",
                OleDbType.VarChar, 50, user.passWord);

                base.AddParameter("@Role",
                OleDbType.VarChar, 20, user.role);

                return ExecuteStoredProcedure();

            }
            catch (System.Exception ExceptionErr)
            {
            	throw new System.Exception(ExceptionErr.Message, 
                ExceptionErr.InnerException);
            }
        }
        public Boolean DeleteUser(int userID)
        {
            try
            {
                base.Access = "usp_DeleteUser";
                base.InitializeCommand();
                base.AddParameter("@UserID", 
                OleDbType.Integer, 10, userID);
                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
                throw new System.Exception(ExceptionErr.Message,
                ExceptionErr.InnerException);
            }
        }
        public Boolean UpdateUser(UserDTO user)
        {
            try
            {
                base.Access = "usp_UpdateUser";
                base.InitializeCommand();

                base.AddParameter("@UserName",
                OleDbType.VarChar, 20, user.userName);

                base.AddParameter("@PassWord",
                OleDbType.VarChar, 50, user.passWord);

                base.AddParameter("@Role",
                OleDbType.VarChar, 20, user.role);

                base.AddParameter("@UserID",
                OleDbType.Integer, 10, user.userID);

                return ExecuteStoredProcedure();
            }
            catch (System.Exception ExceptionErr)
            {
                throw new System.Exception(ExceptionErr.Message,
                ExceptionErr.InnerException);
            }
        }
        public DataSet ValidateLogin(String loginName, String passWord)
        {
            DataSet ds;
            try
            {
                ds = new DataSet();
                base.Access = "usp_ValidateLogin";
                base.InitializeCommand();

                base.AddParameter("@UserName", OleDbType.VarChar, 20, loginName);
                base.AddParameter("@PassWord", OleDbType.VarChar, 50, passWord);

                base.FillDataSet(ref ds, "UserLogin");
                return ds;
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
    }
}
